const Discord = require('discord.js'),
  config = require("../config.json");

module.exports.run = (client, message) => {
    message.delete();
    const embed = new Discord.RichEmbed()
    .setAuthor('arcade selfbot - Selfbot ', message.author.displayAvatarURL)
    .addField('nuke', ' ``Nuke the all server channels and roles.``', true)
    .addField('chn', ' ``Create the raid channels.``', true)
    .addField('everyones', ' ``Make an everyones flood.``', true)
    .addField('banall', ' ``Ban members all.``', true)
    .addField('purge', ' ``purge inative members (1 day).``', true)
    .addField('roni', ' ``Bugs and disable roni  bot.``', true)
    .addField('clear', ' ``Clear all messages.``', true)
    .addField('ghostping', ' ``Ping all server members.``', true)
    .addField('token', ' ``Manda uma parte da token do usuario.``', true)
    .addField('purge', ' ``Remove the inactive members (1 day).``', true)
    .addField('avatar', ' ``steal user avatar.``', true)
    .addField('say', ' ``Say.``', true)
    .setFooter('arcade selfbot by mauri & nestscript')
    .setColor("#0498FF")
    .setImage('https://res.allmacwallpaper.com/get/iMac-21-inch-wallpapers/Clean-up-after-the-Storm-1920x1080/18784-9.jpg')

    message.channel.send(embed);
}
