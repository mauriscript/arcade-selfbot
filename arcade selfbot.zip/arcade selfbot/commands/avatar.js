const discord = require('discord.js')

exports.run = async (client, message, args) => {
const user = message.mentions.users.first() || message.author;
let avatarEmbed = new discord.RichEmbed()
      .setTitle("avatar")
      .setColor(`#000000`)
      .setImage(user.avatarURL)
      .setFooter(`avatar!`)
    message.channel.send(avatarEmbed);
}